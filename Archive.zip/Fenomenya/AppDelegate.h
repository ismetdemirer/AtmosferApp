//
//  AppDelegate.h
//  Fenomenya
//
//  Created by Mehmet ONDER on 25.04.2018.
//  Copyright © 2018 Mehmet ONDER. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

