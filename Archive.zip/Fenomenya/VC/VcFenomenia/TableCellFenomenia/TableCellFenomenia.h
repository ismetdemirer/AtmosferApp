//
//  TableCellFenomenia.h
//  Fenomenya
//
//  Created by Mehmet ONDER on 10.06.2018.
//  Copyright © 2018 Mehmet ONDER. All rights reserved.
//

#import "BaseTableCell.h"
#import "Models.h"
#define CellHeightWithoutDescription 360 * WitdhMultiplier
@interface TableCellFenomenia : BaseTableCell
@property(nonatomic, assign)  Article *article;
@end
