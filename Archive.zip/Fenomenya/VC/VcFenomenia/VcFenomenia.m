//
//  VcFenomenia.m
//  Fenomenya
//
//  Created by Mehmet ONDER on 8.06.2018.
//  Copyright © 2018 Mehmet ONDER. All rights reserved.
//

#import "VcFenomenia.h"
#import "Header.h"
@interface VcFenomenia ()
@property                      NSInteger                  page;

@property (readonly)           UISwipeGestureRecognizer * recognizer_close;
@property (readonly)           UISwipeGestureRecognizer * recognizer_close2;
@property (readonly)           UISwipeGestureRecognizer * recognizer_open;
@property(nonatomic, strong)   NSMutableArray<Article*> *articleList;
@property(nonatomic, strong)   NSMutableArray           *menuList;
@end

@implementation VcFenomenia

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
	[self SetGestures];
	[self GetArticles];
	
	self.lblName.text = [NSString stringWithFormat:@"%@ %@", [User sharedUser].Name, [User sharedUser].Surname];
	self.lblDepartment.text = [User sharedUser].DepartmentName;
	self.lblPoint.text = [NSString stringWithFormat:@"%ld", [User sharedUser].Point];
}

-(void)SetGestures
{
	_recognizer_close = [[UISwipeGestureRecognizer alloc]initWithTarget:self action:@selector(CloseMenu:)];
	_recognizer_close.direction = UISwipeGestureRecognizerDirectionLeft;
	[self.viewMenu addGestureRecognizer:_recognizer_close];
	
	_recognizer_open = [[UISwipeGestureRecognizer alloc]initWithTarget:self action:@selector(OpenMenu:)];
	_recognizer_open.direction = UISwipeGestureRecognizerDirectionRight;
	
	[self.view addGestureRecognizer:_recognizer_open];
	_recognizer_close2 = [[UISwipeGestureRecognizer alloc]initWithTarget:self action:@selector(CloseMenu:)];
	_recognizer_close2.direction = UISwipeGestureRecognizerDirectionLeft;
	[self.view addGestureRecognizer:_recognizer_close2];

}
-(void)viewWillAppear:(BOOL)animated
{
	[super viewWillAppear:animated];
	CGRect frame = self.viewMenu.frame;
	frame.origin.x = -self.viewMenu.frame.size.width;
	self.viewMenu.frame = frame;
	
	self.page = 1;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
#pragma mark
-(NSMutableArray<Article*>*)articleList
{
	if(nil == _articleList)
		_articleList = [[NSMutableArray alloc] init];
	
	return _articleList;
}
-(NSMutableArray*)menuList
{
	if(nil == _menuList)
		_menuList = [[NSMutableArray alloc] initWithObjects:
					 @"Paylaşımlar",@"Paylaştıklarım",@"Kaydettiklerim",@"Bildirimlerim",@"Paylaşım Öner",@"Puan Tablosu",@"Ayarlar", nil];
	
	return _menuList;
}
#pragma mark Table Delegate


- (void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath
{
	if(((indexPath.row + 1) == self.articleList.count)
	   && self.page > 1)
		[self GetArticles];
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
	if(tableView == self.tableList)
	{
		Article *article = [self.articleList objectAtIndex:indexPath.row];
		return CellHeightWithoutDescription + article.ContentSizeHeight;
	}
	
	return 60;
}

-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
	
	return 5;
}

-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
	return 5;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
	[tableView deselectRowAtIndexPath:indexPath animated:NO];
}



#pragma mark Table DataSource
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
	if(tableView == self.tableList)
		return self.articleList.count;
	
	return self.menuList.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
	if(tableView == self.tableList)
	{
		static NSString *identifier = @"tableCellFenomenia";
		TableCellFenomenia *cell = (TableCellFenomenia*)[tableView dequeueReusableCellWithIdentifier:identifier];
		
		if(nil == cell)
		{
			cell = [[TableCellFenomenia alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
			
			
		}
		cell.article = [self.articleList objectAtIndex:indexPath.row];
		
		return cell;
	}
	static NSString *identifierMenu = @"tableCellMenu";
	UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifierMenu];
	if(nil == cell)
	{
		cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifierMenu];
	}
	
	cell.textLabel.text = [self.menuList objectAtIndex:indexPath.row];
	
	return cell;
}

#pragma mark Get Articles
-(void)GetArticles
{
	if(self.page == 1)
	{
		[self.articleList removeAllObjects];
		[self.tableList reloadData];
	}
	
	NSDictionary *params = @
	{
		@"Page":@(self.page),
		@"MemberId":@([User sharedUser].Id)

	};
	
	[self StartActivityWithPointY:500*HeightMultiplier];
	
	[[[WsUtil alloc]
	  initWithCaller:self
	  WithSuccededSel:@selector(GetArticles:WithResponse:)
	  WithFailedSel:@selector(GetArticles:WithError:)]
	 WsCallWithUrl:@"Article/GetAll"
	 WithHttpMethod:HttpPost
	 WithBodyParamters:params];
}
-(void)GetArticles:(WsUtil*)ws WithResponse:(NSDictionary*)response
{
	NSDictionary *dictResponse = response;
	if(nil != dictResponse)
	{
		NSDictionary *data = [dictResponse valueForKey:@"Data"];
		NSMutableArray * articleArray = (NSMutableArray*)[data valueForKey:@"ArticleList"];
		self.page = [[data valueForKey:@"Next"] integerValue];
		
		for (NSDictionary* dict in articleArray) {
			Article *article = [[Article alloc] init];
			article.Id = [[dict valueForKey:@"Id"] integerValue];
		
			article.Title = [dict valueForKey:@"Title"];
			article.Description = [dict valueForKey:@"Description"];
			article.MediaUrl = [dict valueForKey:@"MediaUrl"];
			article.Point = [[dict valueForKey:@"Point"] integerValue];
			article.IsLiked = [[dict valueForKey:@"IsLiked"] boolValue];
			article.IsBookMarked = [[dict valueForKey:@"IsBookMarked"] boolValue];
			article.Link = [dict valueForKey:@"Link"];
			article.TypeId = (ArticleType)[[dict valueForKey:@"TypeId"] integerValue];
			article.ShareCount = [[dict valueForKey:@"ShareCount"] integerValue];
			article.LikeCount = [[dict valueForKey:@"LikeCount"] integerValue];
			article.CreatedDate = [dict valueForKey:@"CreatedDate"];
			
			[self.articleList addObject:article];
			article = nil;
		}
		/*if(statusCode == STATUS_CODE)
		{
			[[User sharedUser] SetUserWithData:data];
			
		}
		else
		{
			[self StopActivity];
			NSString *returnMessage = [dictResponse valueForKey:@"ErrorMessage"];
			[UtilCommon AlertMessageIn:self WithCaption:@"" WithMessageText:returnMessage];
		}*/
		[self StopActivity];
		[self.tableList reloadData];
	}
	ws = nil;
}

-(void)GetArticles:(WsUtil*)ws WithError:(NSError*)error
{
	[self StopActivity];
	
	if([UtilCommon ShowConnectionError:error VC:self])
		[UtilCommon AlertMessageIn:self WithCaption:@"" WithMessageText:error.description];
	
	ws = nil;
}

#pragma mark Open Menu View
-(IBAction)OpenMenuView:(id)sender
{
	[self OpenViewMenu];
}

#pragma mark Open - Close Menu functions
-(void)OpenViewMenu
{
	CGPoint point = self.viewMenu.frame.origin;
	if(point.x ==  0)
	{
		[self CloseViewMenu];
		return;
	}
	else {
		
		self.viewMenu.hidden = NO;
		[UIView beginAnimations:nil context:NULL];
		[UIView setAnimationDuration:0.5];
		[UIView setAnimationDelegate:self];
		
		CGSize sizeMenu = self.viewMenu.frame.size;
		//CGSize sizeMain = self.viewMain.frame.size;
		[self.viewMenu setFrame:CGRectMake(0, 0, sizeMenu.width, sizeMenu.height)];
		
		
		[UIView commitAnimations];
		
	}
}

-(void)CloseViewMenu
{
	[UIView beginAnimations:nil context:NULL];
	[UIView setAnimationDuration:0.5];
	[UIView setAnimationDelegate:self];
	[UIView setAnimationDidStopSelector:@selector(CloseAnimationStopped:finished:context:)];
	CGSize sizeMenu = self.viewMenu.frame.size;
	
	
	[self.viewMenu setFrame:CGRectMake(-sizeMenu.width, 0, sizeMenu.width, sizeMenu.height)];
	
	[UIView commitAnimations];
}
-(void)CloseAnimationStopped:(NSString *)animationID
					finished:(NSNumber *)finished
					 context:(void *)context {
	self.viewMenu.hidden = YES;
}

-(void)CloseMenu:(UISwipeGestureRecognizer *)sender
{
	[self.view endEditing:YES];
	[self CloseViewMenu];
}


-(void)OpenMenu:(UISwipeGestureRecognizer *)sender
{
	[self.view endEditing:YES];
	[self OpenViewMenu];
}
-(void)CloseEditing:(UITapGestureRecognizer *)sender
{
	[self.view endEditing:YES];
	[self CloseViewMenu];
	[super CloseEditing:sender];
}
@end
