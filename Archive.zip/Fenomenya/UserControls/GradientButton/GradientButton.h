//
//  GradientButton.h
//  Fenomenya
//
//  Created by Mehmet ONDER on 10.06.2018.
//  Copyright © 2018 Mehmet ONDER. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GradientButton : UIButton

//@property( nonatomic ) IBInspectable UIColor *startColor;
//@property( nonatomic ) IBInspectable UIColor *endColor;

@end
